(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__1_cxnk7._.css","static/chunks/node_modules_@reduxjs_toolkit_dist_05j2u16._.js","static/chunks/node_modules_motion-dom_dist_es_0g6cuzy._.js","static/chunks/node_modules_framer-motion_dist_es_1_a7n4k._.js","static/chunks/node_modules_06wh6xs._.js","static/chunks/src_0ttw9qa._.js","static/chunks/node_modules_0we6js7._.js","static/chunks/src_0rd9w_y._.js"],
    source: "entry"
});
